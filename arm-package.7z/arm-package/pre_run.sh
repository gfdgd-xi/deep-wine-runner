#!/bin/bash

function CallPreRun()
{
    #x86环境如果不支持32的GLX,d3d改为vulkan的实现
    if [[ ! -f "${WINEPREFIX}/.init_d3d" ]] && [[ -z "$EMU_CMD" ]];then
        "${APPDIR}/run_gl.sh"
        if [ $? != 0 ];then
            WINEPREFIX="$WINEPREFIX" $WINE_CMD regedit /S "${APPDIR}/gdid3d.reg"
        fi
        touch "${WINEPREFIX}/.init_d3d"
    fi

    set -- "$@" "--disable-gpu"
    rm -rf "${WINEPREFIX}/drive_c/users/$USER/Application Data/Tencent/WeChat/XPlugin/Plugins/WMPFRuntime"
    CallProcess "$@"
    exit
}
